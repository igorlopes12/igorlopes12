package appContaCorrente;

import javax.swing.JOptionPane;


public class Principal {

    public static void main(String[] args) {

        ContaCorrente conta; 
        
        String operacoes[] = {"Consultar Saldo", "Depositar", "Sacar", "Sair"};

        String opUsr = ""; 

        String numConta = JOptionPane.showInputDialog(null, "Informe o número da conta", "SisBank", 3);

        String nomeCliente = JOptionPane.showInputDialog(null, "Informe o nome do titular", "SisBank", 3);
        
        float valor;
       
        conta = new ContaCorrente(numConta, nomeCliente); 
       
        while (!opUsr.equals("Sair")) {  
            
            opUsr = (String) JOptionPane.showInputDialog(null, "Selecione a operação desejada:", "SisBank", 3, null, operacoes, operacoes[0]);
         
            switch (opUsr) {
             
                case "Depositar":
                    do {
                        valor = Float.parseFloat(JOptionPane.showInputDialog(null, "Valor a ser depositado", "SisBank", 3));
                    } while (valor <= 0);
                    
                    conta.depositar(valor);
                    JOptionPane.showMessageDialog(null, "Depósito realizado com sucesso!!!", "SisBank", 1);
                    break;

                case "Sacar":
                    do {
                        valor = Float.parseFloat(JOptionPane.showInputDialog(null, "Valor a ser sacado", "SisBank", 3));
                    } while (valor <= 0);
                    
                    boolean sacou = conta.sacar(valor);
                    
                    if (sacou) {
                        JOptionPane.showMessageDialog(null, "Saque realizado com sucesso!!!", "SisBank", 1);
                    } else {
                        JOptionPane.showMessageDialog(null, "Saque não realizado. SALDO INSUFICIENTE!!!", "SisBank", 2);
                    }
                    break;

                case "Consultar Saldo":
                    JOptionPane.showMessageDialog(null, conta.dados(), "SisBank", 3);
            }//fim da estrutura switch

        }//fim da estrutura while

        System.exit(0);
    }//fim do método main
}//fim da classe
