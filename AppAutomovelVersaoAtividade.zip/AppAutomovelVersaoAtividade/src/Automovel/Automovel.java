package Automovel;

import java.time.LocalDate;

public class Automovel {
    //ATRIBUTOS OU VARIÁVEIS DE INSTÂNCIA
    private String marca, modelo, cor, combustivel;
    private double precoCusto;
    private double precoVenda; 
    private int ano;

   //Construtores sobrecarregados
   public Automovel(String marca, String modelo, String cor, String combustivel, double precoCusto, int ano) {
        this.marca = marca;
        this.modelo = modelo;
        this.cor = cor;
        this.combustivel = combustivel;
        this.precoCusto = precoCusto;
        this.ano = ano;
        quantoCusta();
    }

    public Automovel(String marca, String modelo, String cor, String combustivel, double precoCusto) {
        //   this(marca, modelo, cor, combustivel, precoCusto, Calendar.getInstance().get(Calendar.YEAR));
        this(marca, modelo, cor, combustivel, precoCusto, LocalDate.now().getYear());
        quantoCusta();
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getCombustivel() {
        return combustivel;
    }

    public void setCombustivel(String combustivel) {
        this.combustivel = combustivel;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public double getPrecoCusto() {
        return precoCusto;
    }

    public void setPrecoCusto(double precoCusto) {
        this.precoCusto = precoCusto;
    }

    public double getPrecoVenda() {
        return precoVenda;
    }
    
    

    private void quantoCusta() {
        
        switch (combustivel) {
            case "Gasolina":
                precoVenda = getPrecoCusto() + (getPrecoCusto() * 5 / 100);
                break;
            case "Álcool":
                precoVenda = getPrecoCusto() + (getPrecoCusto() * 7 / 100);
                break;
            case "Diesel":
                precoVenda = getPrecoCusto() + (getPrecoCusto() * 15 / 100);
                break;
            case "GNV":
                precoVenda = getPrecoCusto() + (getPrecoCusto() * 3 / 100);
                break;
            case "Flex":
                precoVenda = getPrecoCusto() + (getPrecoCusto() * 10/ 100);
                break;
        }
     }

    public void quantoCusta(int percentual) {
         precoVenda +=  precoVenda * percentual / 100;
    }

    public String dados() {
        java.text.DecimalFormat mascara = new java.text.DecimalFormat("#,##0.00");
        return "Dados do Automóvel\n"
                + "\nMarca: " + marca
                + "\nModelo: " + modelo
                + "\nAno: " + ano
                + "\nCor: " + cor
                + "\nCombustível: " + combustivel
                + "\nPreço de Custo: R$ " + mascara.format(getPrecoCusto())+
                "\nPreço de Venda: R$ "+mascara.format(getPrecoVenda());
              
    }

}
