package Automovel;

import java.time.LocalDate;
import javax.swing.JOptionPane;

public class Principal {

    public static void main(String a[]) {
        String combustivel[] = {"Gasolina", "Álcool", "Diesel", "Flex", "GNV"};
        
        String marca[] = {"VOLKSWAGEN", "FIAT", "FORD", "GENERAL MOTORS", "HONDA", "PEUGEOT", "RENAULT", "TOYOTA"};

        String operacoes[] = {"Cadastrar dados do automóvel", "Visualizar informações", "Reajustar o valor do automóvel", "Sair"};

        Automovel meuAuto=null;

        String opUsr = "";
     
        while (!opUsr.equals("Sair")) {

            opUsr = (String) JOptionPane.showInputDialog(null, "Selecione a operaçao desejada", "Operações", 3, null, operacoes, operacoes[0]);

            switch (opUsr) {
                case "Cadastrar dados do automóvel":
                    String marcaAuto = (String) JOptionPane.showInputDialog(null, "Selecione a marca do automóvel.", "Cadastro", 3, null, marca, marca[1]);
                    String modeloAuto = JOptionPane.showInputDialog(null, "Informe o modelo do automóvel.", "Cadastro", 3);
                    String corAuto = JOptionPane.showInputDialog(null, "Informe a cor do automóvel.", "Cadastro", JOptionPane.QUESTION_MESSAGE);
                    String combAuto = (String) JOptionPane.showInputDialog(null, "Selecione o combustível do automóvel.", "Cadastro", 3, null, combustivel, combustivel[0]);
                    double precoCustoAuto = Double.parseDouble(JOptionPane.showInputDialog(null, "Informe o preço de custo", "Cadastro", 3));
                    int novo = JOptionPane.showConfirmDialog(null, "O automóvel é zero km?", "Cadastro", JOptionPane.YES_NO_OPTION, 3);
                    int ano;
                    if (novo == 0) {
                        ano = LocalDate.now().getYear();
                    } else {
                        ano = Integer.parseInt(JOptionPane.showInputDialog(null, "Informe o ano do automóvel", "Cadastro", JOptionPane.QUESTION_MESSAGE));
                    }
                    
                    meuAuto=new Automovel(marcaAuto,modeloAuto,corAuto,combAuto, precoCustoAuto,ano);
                    break;

                case "Visualizar informações":
                    if (meuAuto!= null) {
                        JOptionPane.showMessageDialog(null, meuAuto.dados(), "Consulta", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Efetue, primeiramente, o cadastro do automóvel", "Consulta", JOptionPane.ERROR_MESSAGE);
                    }
                    break;

                case "Reajustar o valor do automóvel":
                    if (meuAuto!= null) {
                        int perc = Integer.parseInt(JOptionPane.showInputDialog(null, "Percentual de reajuste?","Reajustar valor do automóvel",1));
                        meuAuto.quantoCusta(perc);
                    } else {
                        JOptionPane.showMessageDialog(null, "Efetue, primeiramente, o cadastro do automóvel", "Reajustar valor do automóvel", JOptionPane.ERROR_MESSAGE);
                    }
            }
        }
            System.exit(0);
            
        }
    }
