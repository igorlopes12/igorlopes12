
package appautomovel;

import java.time.LocalDate;

public class Automovel {
    //Atributos
    private String marca;
    private String modelo;
    private int ano;
    private String combustivel;
    private String cor;
    private double precoDeCusto;
    
    //Construtores sobrecarregados
    public Automovel(String marca, String modelo, String combustivel, String cor, double precoDeCusto,int ano) {
        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
        this.combustivel = combustivel;
        this.cor = cor;
        this.precoDeCusto = precoDeCusto;
    }
    
    public Automovel(String marca, String modelo, String combustivel, String cor, double precoDeCusto) {
        this(marca,modelo,combustivel,cor,precoDeCusto,LocalDate.now().getYear());
    }

    public Automovel() {
    }
    
    //Métodos
    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getCombustivel() {
        return combustivel;
    }

    public void setCombustivel(String combustivel) {
        this.combustivel = combustivel;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public double getPrecoDeCusto() {
        return precoDeCusto;
    }

    public void setPrecoDeCusto(double precoDeCusto) {
        this.precoDeCusto = precoDeCusto;
    }
    
    public String dados(){
        return "Dados do Automóvel\n"+
                "\nModelo: "+modelo+
                "\nMarca: "+marca+
                "\nAno: "+ano+
                "\nCor: "+cor+
                "\nCombustível: "+combustivel+
                "\nPreço de Custo R$ "+precoDeCusto+
                "\nPreço de Venda R$ "+quantoCusta();
    }
    
   
    //Sobrecarga de métodos
    public double quantoCusta(float percentual){
        double precoVenda=precoDeCusto+ (precoDeCusto*percentual/100);
        return precoVenda;
    }
    
    public double quantoCusta(){
        double precoVenda=0;
        if (combustivel.equalsIgnoreCase("Gasolina")){
            precoVenda=quantoCusta(5);
        }else  if (combustivel.equalsIgnoreCase("Álcool")){
            precoVenda=quantoCusta(7);
        }else  if (combustivel.equalsIgnoreCase("Diesel")){
            precoVenda=quantoCusta(15);
        }else  if (combustivel.equalsIgnoreCase("GNV")){
            precoVenda=quantoCusta(3);
        }else  if (combustivel.equalsIgnoreCase("Flex")){
            precoVenda=quantoCusta(10);
        }
        return precoVenda;
    }
    
}
