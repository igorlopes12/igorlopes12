
package appautomovel;

import javax.swing.JOptionPane;

public class Principal {
    public static void main(String[] args) {
        String []combustiveis={"Gasolina","Álcool","Diesel","GNV","Flex"};
        
        Automovel meuAuto; //declaração do objeto
        
        String marca=JOptionPane.showInputDialog(null,"Informe a marca", "AppAutomovel",3);
        String modelo=JOptionPane.showInputDialog("Informe o modelo");
        String cor=JOptionPane.showInputDialog(null,"Informe a cor");
        String combustivel = (String)   JOptionPane.showInputDialog(null,"Selecione o combustível",
                                                                         "AppAutomovel", 3, null, combustiveis,combustiveis[4]);
        double precoCusto=Double.parseDouble(JOptionPane.showInputDialog(null,"Informe o preço de custo","AppAutomovel",3));
        int novo=JOptionPane.showConfirmDialog(null, "O automóvel é zero km?", "AppAutomovel",JOptionPane.YES_NO_OPTION,3 );
        
        if (novo == 0){
            meuAuto=new Automovel(marca,modelo, combustivel, cor, precoCusto);
        }else{
            int ano = Integer.parseInt(JOptionPane.showInputDialog(null,"Informe o ano do automóvel","AppAutomovel",3));
            meuAuto=new Automovel(marca,modelo, combustivel, cor,precoCusto,ano);
        }
        
        JOptionPane.showMessageDialog(null, meuAuto.dados(),"AppAutomovel",1);
        System.exit(0);
        
    }
    
}
